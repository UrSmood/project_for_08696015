import datetime

import pandas as pd
import requests

data = pd.read_excel('股票数据.xlsx')

top20 = data['股票代码'].tolist()[:2]

print(top20)
headers = {
    'authority': 'stock.xueqiu.com',
    'accept': 'application/json, text/plain, */*',
    'accept-language': 'zh-CN,zh;q=0.9',
    'cache-control': 'no-cache',
    'cookie': 'device_id=e6dc3c7bbe7af5f7402b9ab48112a099; s=cd1ag1ddc3; xq_a_token=7da3658c0a79fd9ef135510bc5189429ce0e3035; xqat=7da3658c0a79fd9ef135510bc5189429ce0e3035; xq_r_token=c4e290f788b8c24ec35bd4b893dc8fa427e1f229; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOi0xLCJpc3MiOiJ1YyIsImV4cCI6MTY3OTk2MjkxMiwiY3RtIjoxNjc4MDcyNzU3MDA1LCJjaWQiOiJkOWQwbjRBWnVwIn0.Rh70SBNHUxS9t0JuHH5mZx6iEouehJqCvD1ZSy0uJgEXUD5GmnIypvuzqJnEQzNz-JuKOxSHnR-EPTbU0T4yw8fEoVuBwM9aPfEjH6iRJK9ltMVL0zt8UgQC-Jik87UTnKiDE5dkGpwkhJtomRVOdNG5kgs7m5P_45eFST5JeTaOq0gxvdwfYExS9dRqTuzHUkh1X1Fs5HM4UUq7AqG9aQ77kSO8_Ihmsp7L__yXDO1sIy4emao5MSVU3of35v6KldSeJnnbdZ4Zlg1iJRoKfoWMiwMjYBH-Iuk0S5-WBpmRxGreUIAzzUkHDYf26ceBCN9DzbwpxlwR7F-CCtvS2w; u=921678072781775; Hm_lvt_1db88642e346389874251b5a1eded6e3=1677914761,1677981478,1677981478,1678072782; is_overseas=0; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1678102987',
    'origin': 'https://xueqiu.com',
    'pragma': 'no-cache',
    'referer': 'https://xueqiu.com/S/SH600519',
    'sec-ch-ua': '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
}
for t in top20:
    url = f'https://stock.xueqiu.com/v5/stock/chart/kline.json?symbol={t}&begin=1678189392831&period=day&type=before&count=-284&indicator=kline,pe,pb,ps,pcf,market_capital,agt,ggt,balance'
    response = requests.get(url, headers=headers).json()
    res = response.get('data').get('item')
    data_list = []
    for r in res:
        print(r[0])
        r[0] = datetime.datetime.fromtimestamp(r[0] // 1000).strftime("%Y-%m-%d")
        data_list.append([r[0], r[2], r[3], r[4], r[5], r[6], r[7], r[1], r[9], r[8]])
    name = response.get('data').get('symbol')
    title = ['时间', '开盘价', '最高价', '最低价', '收盘价', '涨跌额', '涨跌幅', '成交量', '成交额', '换手率']
    excel_data = pd.DataFrame(data=data_list, columns=title)
    excel_data.to_excel(f'{name}.xlsx', index=False)
