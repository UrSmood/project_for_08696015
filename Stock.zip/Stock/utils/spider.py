import pandas as pd
import pymysql
import requests


def get_data():
    headers = {
        'authority': 'stock.xueqiu.com',
        'accept': 'application/json, text/plain, */*',
        'accept-language': 'zh-CN,zh;q=0.9',
        'cache-control': 'no-cache',
        'cookie': 'device_id=e6dc3c7bbe7af5f7402b9ab48112a099; s=cd1ag1ddc3; xq_a_token=7da3658c0a79fd9ef135510bc5189429ce0e3035; xqat=7da3658c0a79fd9ef135510bc5189429ce0e3035; xq_r_token=c4e290f788b8c24ec35bd4b893dc8fa427e1f229; xq_id_token=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJ1aWQiOi0xLCJpc3MiOiJ1YyIsImV4cCI6MTY3OTk2MjkxMiwiY3RtIjoxNjc4MDcyNzU3MDA1LCJjaWQiOiJkOWQwbjRBWnVwIn0.Rh70SBNHUxS9t0JuHH5mZx6iEouehJqCvD1ZSy0uJgEXUD5GmnIypvuzqJnEQzNz-JuKOxSHnR-EPTbU0T4yw8fEoVuBwM9aPfEjH6iRJK9ltMVL0zt8UgQC-Jik87UTnKiDE5dkGpwkhJtomRVOdNG5kgs7m5P_45eFST5JeTaOq0gxvdwfYExS9dRqTuzHUkh1X1Fs5HM4UUq7AqG9aQ77kSO8_Ihmsp7L__yXDO1sIy4emao5MSVU3of35v6KldSeJnnbdZ4Zlg1iJRoKfoWMiwMjYBH-Iuk0S5-WBpmRxGreUIAzzUkHDYf26ceBCN9DzbwpxlwR7F-CCtvS2w; u=921678072781775; Hm_lvt_1db88642e346389874251b5a1eded6e3=1677914761,1677981478,1677981478,1678072782; Hm_lpvt_1db88642e346389874251b5a1eded6e3=1678076733',
        'origin': 'https://xueqiu.com',
        'pragma': 'no-cache',
        'referer': 'https://xueqiu.com/hq',
        'sec-ch-ua': '".Not/A)Brand";v="99", "Google Chrome";v="103", "Chromium";v="103"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-site',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36',
    }

    url = 'https://stock.xueqiu.com/v5/stock/screener/quote/list.json?page=1&size=1710&order=desc&orderby=market_capital&order_by=market_capital&market=CN&type=sh_sz'
    response = requests.get(url, headers=headers, ).json()
    # print(response)
    res = response.get('data').get('list')

    data_list = []
    for r in res:
        data_list.append([r["symbol"],
                          r["name"],
                          str(r["current"]),
                          str(r["chg"]),
                          str(r["percent"]),
                          str(r["current_year_percent"]),
                          str(r["volume"]),
                          str(r["amount"]),
                          str(r["turnover_rate"]),
                          str(r["pe_ttm"]),
                          str(r["dividend_yield"]),
                          str(r["market_capital"])])

    return data_list


def save_excel(data_list):
    title = ['股票代码', '股票名称', '当前价', '涨跌额', '涨跌幅', '年初至今', '成交量',
             '成交额', '换手率', '市盈率(TTM)', '股息率', '市值']
    excel_data = pd.DataFrame(data=data_list, columns=title)
    excel_data.to_excel(f'股票数据.xlsx', index=False)


def save_sql(data_list):
    conn = pymysql.connect(host="1.15.230.146",
                           port=3306,
                           user="stock",
                           password="stock",
                           database="stock",
                           charset="utf8")
    cursor = conn.cursor()

    for i in data_list:
        sql = '''
            insert into tb_stock(symbol, name, current ,chg, percent, current_year_percent, 
            volume,amount, turnover_rate, pe_ttm, dividend_yield, market_capital)
            values(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        '''
        print(i)
        cursor.execute(sql, i)
        conn.commit()

    cursor.close()
    conn.close()


if __name__ == '__main__':
    data = get_data()
    save_sql(data)