import sqlite3

import pandas as pd


def query_database(query, args=()):
    conn = sqlite3.connect('user_info.db')
    try:
        with conn:
            cursor = conn.cursor()
            cursor.execute(query, args)
            result = cursor.fetchall()
            conn.commit()
    finally:
        conn.close()
    return result


def get_dataframe(query, args=()):
    conn = sqlite3.connect('user_info.db')
    cursor = conn.cursor()
    cursor.execute(query, args)
    result = cursor.fetchall()
    headers = [i[0] for i in cursor.description]
    conn.commit()
    conn.close()
    data = [headers] + list(result)
    df = pd.DataFrame(data[1:], columns=data[0])
    # print(df)
    return df


if __name__ == '__main__':
    query = 'select * from tb_user'
    get_dataframe(query)